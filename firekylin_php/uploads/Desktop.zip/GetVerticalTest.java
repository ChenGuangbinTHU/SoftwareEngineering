

import static org.junit.Assert.assertEquals;

import org.junit.Test;



public class GetVerticalTest {

  @Test
    public void test_z_z() {
    GetVertical get = new GetVertical();
    Vec v1 = new Vec(0,0,0);
    Vec v2 = new Vec(0,0,0);
    get.getVertical(v1, v2);
  }
  
  @Test
    public void test_z_n() {
    GetVertical get = new GetVertical();
    Vec v1 = new Vec(0,0,0);
    Vec v2 = new Vec(1,0,0);
    get.getVertical(v1, v2);
  }

  @Test
    public void test_p_p() {
    GetVertical get = new GetVertical();
    Vec v1 = new Vec(1,0,0);
    Vec v2 = new Vec(2,0,0);
    get.getVertical(v1, v2);
  }

  @Test
    public void test_n_n() {
    GetVertical get = new GetVertical();
    Vec v1 = new Vec(1,0,0);
    Vec v2 = new Vec(0,21,2);
    get.getVertical(v1, v2);
  }

}
