

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class OperationTest {

  @Test
    public void test_zero_cross_zero() {
    Operation operation = new Operation();
    Vec v1 = new Vec(0,0,0);
    Vec v2 = new Vec(0,0,0);
    Vec v3 = new Vec(0,0,0);
    Vec result = operation.cross(v1, v2);
    //System.out.println(result.x);
    //assertEquals(v3, result);
  }

  @Test
    public void test_zero_dot_zero() {
    Operation operation = new Operation();
    Vec v1 = new Vec(0,0,0);
    Vec v2 = new Vec(0,0,0);
    double result = operation.dot(v1, v2);
    assertEquals(0.0, result,0.1);
  }

  @Test
    public void test_zero_cross_normal() {
    Operation operation = new Operation();
    Vec v1 = new Vec(0,0,0);
    Vec v2 = new Vec(1,1,1);
    operation.cross(v1, v2);
  }

  @Test
    public void test_p1_cross_p2() {
    Operation operation = new Operation();
    Vec v1 = new Vec(0,1,0);
    Vec v2 = new Vec(0,2,0);
    operation.cross(v1, v2);
  }

  @Test
    public void test_n1_cross_n2() {
    Operation operation = new Operation();
    Vec v1 = new Vec(8,9,1);
    Vec v2 = new Vec(21,4,2);
    operation.cross(v1, v2);
  }

  @Test
    public void test_zero_dot_n1() {
    Operation operation = new Operation();
    Vec v1 = new Vec(0,0,0);
    Vec v2 = new Vec(1,1,1);
    double result = operation.dot(v1, v2);
    assertEquals(0.0, result,0.1);
  }

  @Test
    public void test_v1_dot_v2() {
    Operation operation = new Operation();
    Vec v1 = new Vec(0,1,0);
    Vec v2 = new Vec(1,0,0);
    double result = operation.dot(v1, v2);
    assertEquals(0.0, result,0.1);
  }

  @Test
    public void test_n1_dot_n2() {
    Operation operation = new Operation();
    Vec v1 = new Vec(1,1,0);
    Vec v2 = new Vec(1,0,1);
    double result = operation.dot(v1, v2);
    assertEquals(1.0, result,0.1);
  }
}
